package com.example.Shoppingmall_Costumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingmallCostumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
