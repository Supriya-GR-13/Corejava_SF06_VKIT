package com.example.Shoppingmall_Costumer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Shoppingmall_Costumer.entity.Customer_entity;


@Repository
public interface Costumer_repo extends JpaRepository<Customer_entity,Integer>
{

}
