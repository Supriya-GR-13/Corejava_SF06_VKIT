package com.example.Shoppingmall_Costumer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
//postman->controller->service->repository->database

import com.example.Shoppingmall_Costumer.entity.Customer_entity;
import com.example.Shoppingmall_Costumer.service.Costumer_service;

@RestController
public class Costumer_controller {
	
	@Autowired
	public Costumer_service ss;
	
	@PostMapping("/add") //save
	public Customer_entity registerstudnet(@RequestBody Customer_entity s) {
		return ss.registercustomer(s);
	}
	
	@GetMapping("/getstudnet") // get
	public List<Customer_entity> getstudents()
	{
		return ss.getcustomers();
	}
	
	@DeleteMapping("/deletecustomer/{id}")// delete 
	public void deletestudent(@PathVariable("sid") Integer id) {
		ss.deletecustomer(id);
	}
}


 


