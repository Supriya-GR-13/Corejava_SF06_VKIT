package com.example.Shoppingmall_Costumer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Shoppingmall_Costumer.entity.Customer_entity;
import com.example.Shoppingmall_Costumer.repository.Costumer_repo;

@Service
public class Costumer_service {
	
	@Autowired
	private Costumer_repo sr;

	// create 
	
		public Customer_entity registercustomer(Customer_entity s) {
			return sr.save(s);
		}
		
		// read
		
		public List<Customer_entity> getcustomers(){
			return (List<Customer_entity>) sr.findAll();
		}
		
		//delete
		
		public void deletecustomer(Integer id) {
			sr.deleteById(id);
		}


}
